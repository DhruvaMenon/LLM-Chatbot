import requests
from bs4 import BeautifulSoup
import pandas as pd

df = pd.read_csv('bakabaka\karunya_sitemap_output.txt')

# URL of the website you want to scrape
url = "https://www.karunya.edu/agriculture"
# Send a GET request to the URL0
    
 
response = requests.get(url)

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(response.content, "html.parser")

# Print the HTML content
print(soup.get_text())
