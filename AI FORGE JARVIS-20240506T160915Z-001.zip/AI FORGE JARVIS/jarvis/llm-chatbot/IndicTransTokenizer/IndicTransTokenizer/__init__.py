from .tokenizer import IndicTransTokenizer
from .processor import IndicProcessor
from .evaluate import indic_evaluate
