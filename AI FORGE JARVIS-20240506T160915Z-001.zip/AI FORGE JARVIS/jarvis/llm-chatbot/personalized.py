import nltk
from nltk.chat.util import Chat, reflections

# Define the responses for each course or department
responses = {
    'computer science': [
        "The Computer Science department covers a wide range of topics, including programming, algorithms, data structures, software engineering, and more. What specific area would you like to know about?",
        "Computer Science is a rapidly evolving field with numerous specializations. Please let me know which aspect you're interested in, such as artificial intelligence, cybersecurity, or web development."
    ],
    'business': [
        "The Business department offers courses in management, marketing, finance, accounting, and entrepreneurship. Which area would you like to learn more about?",
        "Business studies encompass various disciplines aimed at preparing students for successful careers. Could you specify the business-related topic you're interested in?"
    ],
    'engineering': [
        "The Engineering department covers various disciplines, including civil, mechanical, electrical, and computer engineering. Which specific branch of engineering are you interested in exploring?",
        "Engineering is a vast field with many specializations. Please let me know which area, such as robotics, construction, or renewable energy, you'd like to know more about."
    ],
    # Add more courses or departments and responses as needed
}

# Define the chatbot's initial prompt
chatbot_prompt = "Welcome to the university course information chatbot! Please select a course or department from the following options: computer science, business, engineering."

# Define a function to handle user input
def chat_response(user_input):
    user_input = user_input.lower()
    if user_input in responses:
        return responses[user_input]
    else:
        return ["I'm sorry, I don't have information on that course or department. Please select from the available options: computer science, business, engineering."]

# Create a NLTK chatbot
chatbot = Chat(chat_response, reflections)

# Start the chatbot conversation
print(chatbot_prompt)
chatbot.converse()