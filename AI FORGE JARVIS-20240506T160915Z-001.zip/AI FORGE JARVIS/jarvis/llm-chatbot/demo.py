# from transformers import AutoModelForTokenClassification, AutoTokenizer

# model_name = "ai4bharat/indic-bert"
# model = AutoModelForTokenClassification.from_pretrained(model_name)
# tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)

# text = "Your input text in Vernacular Language"
# inputs = tokenizer(text, return_tensors="pt")
# outputs = model(**inputs)
# predictions = outputs.logits.argmax(dim=2)

# predicted_labels = [model.config.id2label[label_id] for label_id in predictions[0]]

# named_entities = []
# current_entity = ""
# for token, label in zip(tokenizer.convert_ids_to_tokens(inputs["input_ids"][0]), predicted_labels):
#     if label.startswith("B-"):
#         named_entities.append(current_entity)
#         current_entity = token
#     elif label.startswith("I-"):
#         current_entity += " " + token

# if current_entity:
#     named_entities.append(current_entity)

# print(named_entities)




import os
import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    pipeline
)
#from datasets import load_dataset
from peft import LoraConfig, PeftModel

from langchain.text_splitter import CharacterTextSplitter
from langchain.document_transformers import Html2TextTransformer
from langchain.document_loaders import AsyncChromiumLoader

from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS

from langchain.prompts import PromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from langchain.llms import HuggingFacePipeline
from langchain.chains import LLMChain
from langchain_community.document_loaders import AsyncChromiumLoader
import nest_asyncio
nest_asyncio.apply()

# Articles to index
articles = ["https://admissions.karunya.edu/",
            "https://admissions.karunya.edu/whykarunya",
            "https://admissions.karunya.edu/ug",
            "https://admissions.karunya.edu/pg",
            "https://admissions.karunya.edu/programmes/research",
            "https://admissions.karunya.edu/nri-admission",
            "https://admissions.karunya.edu/scholarships",
            "https://admissions.karunya.edu/programmes/research"]

# Scrapes the blogs above
loader = AsyncChromiumLoader(articles)
docs = loader.load()

# Converts HTML to plain text
html2text = Html2TextTransformer()
docs_transformed = html2text.transform_documents(docs)

# Chunk text
text_splitter = CharacterTextSplitter(chunk_size=100,
                                      chunk_overlap=0)
chunked_documents = text_splitter.split_documents(docs_transformed)

# Load chunked documents into the FAISS index
db = FAISS.from_documents(chunked_documents,
                          HuggingFaceEmbeddings(model_name='sentence-transformers/all-mpnet-base-v2'))

retriever = db.as_retriever()